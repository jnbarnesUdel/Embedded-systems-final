/******************************************************************************
*
* Copyright (C) 2009 - 2014 Xilinx, Inc.  All rights reserved.
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* Use of the Software is limited solely to applications:
* (a) running on a Xilinx device, or
* (b) that interact with a Xilinx device through a bus or interconnect.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
* XILINX  BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
* OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*
* Except as contained in this notice, the name of the Xilinx shall not be used
* in advertising or otherwise to promote the sale, use or other dealings in
* this Software without prior written authorization from Xilinx.
*
******************************************************************************/

/*
 * helloworld.c: simple test application
 *
 * This application configures UART 16550 to baud rate 9600.
 * PS7 UART (Zynq) is not initialized by this application, since
 * bootrom/bsp configures it to baud rate 115200
 *
 * ------------------------------------------------
 * | UART TYPE   BAUD RATE                        |
 * ------------------------------------------------
 *   uartns550   9600
 *   uartlite    Configurable only in HW design
 *   ps7_uart    115200 (configured by bootrom/bsp)
 */

#include <stdio.h>
#include "platform.h"
#include "xil_printf.h"
#include<stdlib.h>
#include<sys/time.h>
#include "xscutimer.h"
#include "xtime_l.h"

volatile u32* const mult = (u32* const)XPAR_NEW_MATRIX_MULT_0_S00_AXI_BASEADDR;
#define TIMER_LOAD_VALUE 1000000000

int main()
{
    init_platform();
    int Status;
    int timer_value;
    int counter = 0;
    volatile u32 CntValue1 = 0;
    volatile u32 CntValue2 = 0;
    XTime Fstart, Fend, Cstart, Cend;


    int N = 5;
    int A[N][N];
    int B[N][N];
    int C[N][N];
    int test[N][N];



    for(int i = 0; i<N; i++){
		for(int j = 0; j<N; j++){
			A[i][j] = rand() % 65536; // %2 ^ 16
			B[i][j] = rand() % 65536;
		}
    }

    XTime_GetTime(&Cstart);
    for(int i = 0; i<N; i++){
		for(int j = 0; j<N; j++){
			for(int k = 0; k<N; k++){
				test[i][j] += A[i][k] * B[k][j];
			}
		}
	}
    XTime_GetTime(&Cend);


    //xil_printf("time spent = %d \n\r", (double)(tv2.tv_usec - tv1.tv_usec) / 1000000 +(double)(tv2.tv_sec - tv1.tv_sec));

    int numberFour = 0;
	numberFour = N/5;
	if(N %5 != 0){
		numberFour++;
	}
	int tile = 5;
	XTime_GetTime(&Fstart);//start of the actual for loop for matrix mult
	for(int row = 0; row < numberFour; row++){
		for(int col = 0; col < numberFour; col++){
			for(int k = 0; k < numberFour; k++){
				for(int i = 0; i<tile; i++){
					for(int j = 0; j<tile; j++){
						if(row*5 + i < N && k * 5 + j < N){
							mult[5*i + j] = A[row*5 +i][k *5 +j];
						}
						else{
							mult[5*i + j] = 0;
						}

						if(k*5 + i < N && col * 5 + j < N){
							mult[5 * i + j + 25] = B[k *5 + i][col * 5 +j];
						}
						else{
							mult[5 * i + j + 25] = 0;
						}
					}
				}
				for(int i = 0; i<tile; i++){
					for(int j = 0; j<tile; j++){
						//c[i][j] = c[i][j] + a * b
						if(i + row * 5 < N && j + col * 5 < N){
							C[i + row*5][j + col*5] = C[i + row * 5][j + col * 5] + mult[5*i +j + 50];//is it actualy 50 though

						}

					}
				}
			}
		}
	}
	XTime_GetTime(&Fend);

	xil_printf("CPU data: \n\r");
	for(int i = 0; i< N; i++){
		for(int j = 0; j< N; j++){
			xil_printf("%d, ", test[i][j]);
		}
		xil_printf("\n\r");
	}
	//4
	printf("Time: %.6fs\n\r", 1.0 * (Cend - Cstart)/COUNTS_PER_SECOND);

	xil_printf("FPGA data: \n\r");
	int correctness = 0;
    for(int i = 0; i < N; i++){
    	for(int j = 0; j <N; j++){
    		xil_printf("%d, ", C[i][j]);
    		if(C[i][j] == test[i][j]){
    			correctness++;
    		}

    	}
    	xil_printf("\n\r");
    }
    printf("Time: %.6fs\n\r", 1.0 * (Fend -Fstart)/COUNTS_PER_SECOND);


    if(correctness == N * N){
    	xil_printf("correct\n\r");
    }
    else{
    	xil_printf("incorrect\n\r");
    }

    if((Fend - Fstart)/COUNTS_PER_SECOND < (Cend - Cstart)/COUNTS_PER_SECOND){
    	xil_printf("Faster Than CPU\n\r");
    }
    else{
    	xil_printf("Slower Than CPU%\n\r");
    }

    cleanup_platform();
    return 0;
}
